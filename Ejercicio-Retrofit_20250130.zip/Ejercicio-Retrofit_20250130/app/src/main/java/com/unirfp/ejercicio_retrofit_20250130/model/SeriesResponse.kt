package com.unirfp.ejercicio_retrofit_20250130.model

class SeriesResponse : ArrayList<Serie>()