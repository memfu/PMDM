package com.unirfp.ae2_api_martinfuentes_mariaeugenia.model

data class Rating(
    val Source: String,
    val Value: String
)